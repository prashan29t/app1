import re
import dns.resolver
import smtplib
import asyncio
import sys
import time
import logging
from flask import Flask, request, jsonify
from multiprocessing import Pool

# Set up the event loop policy for Windows
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

# Initialize the Flask app
app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)

# Cache for MX records to avoid repeated DNS lookups
mx_cache = {}

def load_domains(file_name):
    with open(file_name, 'r') as f:
        return set(line.strip().lower() for line in f if line.strip() and not line.startswith('#'))

# Load disposable, free email domains, and role-based emails once
DISPOSABLE_EMAIL_DOMAINS = load_domains('disposable-emails-domains.txt')
FREE_EMAIL_PROVIDERS = load_domains('free-emails-domains.txt')
ROLE_BASED_EMAILS = load_domains('role-emails-domains.txt')

def is_valid_email_syntax(email):
    """Check if the email syntax is valid."""
    email_regex = re.compile(r"[^@]+@[^@]+\.[^@]+")
    return email_regex.match(email) is not None

def get_mx_records(domain):
    """Get MX records for a domain, using a cache to avoid repeated lookups."""
    if domain in mx_cache:
        return mx_cache[domain]

    try:
        answers = dns.resolver.resolve(domain, 'MX')
        mx_records = [str(rdata.exchange).lower() for rdata in answers]
        mx_cache[domain] = mx_records
        return mx_records
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.resolver.NoNameservers) as e:
        logging.error(f"DNS query failed for {domain}: {e}")
        mx_cache[domain] = []
        return []
    except Exception as e:
        logging.error(f"Unexpected error occurred while resolving MX records for {domain}: {e}")
        mx_cache[domain] = []
        return []

def verify_email_smtp(email, email_count, total_emails):
    """Verify the email using SMTP."""
    domain = email.split('@')[-1]
    mx_records = get_mx_records(domain)
    if not mx_records:
        return False, "No MX records found.", []

    for mx_record in mx_records:
        try:
            start_time = time.time()  # Start timing
            with smtplib.SMTP(mx_record, timeout=2) as server:  # Set timeout to 2 seconds
                server.helo()
                server.mail('you@example.com')
                code, message = server.rcpt(email)
                end_time = time.time()  # End timing

                time_taken = end_time - start_time
                status = "valid" if code == 250 else "invalid"
                logging.info(f"EMAIL {email_count}/{total_emails} Time taken for [{status}] {email} on {mx_record}: {time_taken:.2f} seconds --- With code {code} ")
                logging.warning(f"{code} --- {message.decode()}")
                if code == 250:
                    return True, "SMTP check passed.", mx_record
                else:
                    logging.warning(f"SMTP check failed for {email} on {mx_record} with code {code} and message: {message.decode()}")

        except Exception as e:
            logging.error(f"SMTP connection failed with {mx_record}: {e}")

    return False, "All MX records failed SMTP check.", mx_records

def is_role_based_email(email):
    """Check if the email is role-based."""
    local_part = email.split('@')[0].lower()
    return any(local_part.startswith(role) for role in ROLE_BASED_EMAILS)

def is_disposable_email(email):
    """Check if the email is from a disposable email provider."""
    domain = email.split('@')[-1].lower()
    return domain in DISPOSABLE_EMAIL_DOMAINS

def is_free_email(email):
    """Check if the email is from a free email provider."""
    domain = email.split('@')[-1].lower()
    return domain in FREE_EMAIL_PROVIDERS

def check_email(email, email_count, total_emails):
    """Check email validity and provide detailed status."""
    start_time = time.time()  # Start timing the whole check

    if not is_valid_email_syntax(email):
        elapsed_time = time.time() - start_time
        return {
            "time": elapsed_time,
            "email": email,
            "status": "invalid",
            "user": email.split('@')[0],
            "domain": email.split('@')[-1],
            "disposable": False,
            "role": False,
            "free_email": False,
            "valid_format": False,
            "reason": "Invalid email syntax.",
            "mx_domain": "",
            "mx_record": []
        }

    domain = email.split('@')[-1]
    mx_records = get_mx_records(domain)
    if not mx_records:
        elapsed_time = time.time() - start_time
        return {
            "time": elapsed_time,
            "email": email,
            "status": "invalid",
            "user": email.split('@')[0],
            "domain": domain,
            "disposable": False,
            "role": False,
            "free_email": False,
            "valid_format": True,
            "reason": f"Domain '{domain}' has no MX records.",
            "mx_domain": "",
            "mx_record": []
        }

    is_valid, reason, mx_record = verify_email_smtp(email, email_count, total_emails)
    elapsed_time = time.time() - start_time

    return {
        "time": elapsed_time,
        "email": email,
        "status": "valid" if is_valid else "invalid",
        "user": email.split('@')[0],
        "domain": domain,
        "disposable": is_disposable_email(email),
        "role": is_role_based_email(email),
        "free_email": is_free_email(email),
        "valid_format": True,
        "reason": reason if not is_valid else "Valid email.",
        "mx_domain": domain,
        "mx_record": mx_record
    }

def validate(args):
    """Validate a single email and return detailed results."""
    email, email_count, total_emails = args
    return check_email(email, email_count, total_emails)

@app.route('/check-emails', methods=['POST'])
def check_emails_api():
    """API endpoint to check a list of emails."""
    data = request.json
    email_list = data.get('emails', [])
    total_emails = len(email_list)

    if not isinstance(email_list, list):
        return jsonify({'error': 'Invalid input, expected a list of emails.'}), 400

    pool = Pool()
    args = [(email, count + 1, total_emails) for count, email in enumerate(email_list)]
    results = pool.map(validate, args)
    pool.close()
    pool.join()
    return jsonify({"data": results})

if __name__ == '__main__':
    import sys
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5001
    app.run(host='0.0.0.0', port=port)